﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderstandingScope
{
    class Program
    {
        private static string k = "";
        static void Main(string[] args)
        {
           

            for(int i = 1; i < 10; i++)
            {
                Console.WriteLine(i);
                k = i.ToString();

            }//end for
            MessageofK();
            //create an instance
            moreMessages mm = new moreMessages();
            mm.NewMessage();

            //to make program pause
            Console.ReadLine();
        }//end main
       static void MessageofK()
        {
            Console.WriteLine("Value of variable k is " + k);
        }


    }//end class

    //create new class
    class moreMessages
    {
        public void NewMessage()
        {
            Console.WriteLine("hello ");
            AdditionalMessage();
        }

        private void AdditionalMessage()
        {
            Console.WriteLine("world");
        }
    }//end class moreMessages
}//end namespace
