﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListsAadDictionaries
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car1 = new Car();
            car1.Make = "Chevy";
            car1.Model = "Corvette";
            car1.VIN = "123A";

            Car car2 = new Car();
            car2.Make = "Ford";
            car2.Model = "Fusion";
            car2.VIN = "456A";

            Car car3 = new Car() { Make = "BMW", Model = "328i", VIN = "999C" };

            //create instance dummy class
            Employee emp1 = new Employee() { Name = "Don", Title = "Instructor", Dept = "BEIT" };

            //remember arraylist?
            ArrayList myArrayList = new ArrayList();
            //add objects to arraylist
            myArrayList.Add(car1);
            myArrayList.Add(car2);
            myArrayList.Add(car3);
            //myArrayList.Add(emp1);

            foreach(Car auto in myArrayList)
            {
                Console.WriteLine(auto.Make);
            }

            //Lists
            List<Car> myList = new List<Car>();
            myList.Add(car1);
            myList.Add(car2);
            myList.Add(car3);

            foreach (Car auto in myList)
            {
                Console.WriteLine(auto.Model);
            }


            //using dictionary
            Dictionary<string, Car> myDictionary = new Dictionary<string, Car>();
            myDictionary.Add(car1.VIN, car1);
            myDictionary.Add(car2.VIN, car2);
            myDictionary.Add(car3.VIN, car3);

            //ways to print info
            Console.WriteLine(myDictionary["123A"].Make);

            //ALL INFO
            Console.WriteLine("VIN={0}, Make ={1}, Model ={2}", myDictionary["123A"].VIN, myDictionary["123A"].Make, myDictionary["123A"].Model);

            //FOR ALL CARS
            foreach(Car car in myDictionary.Values)
            {
                Console.WriteLine("VIN={0}, Make ={1}, Model ={2}", car.VIN, car.Make, car.Model);
                Console.WriteLine("-------------------------------------");
            }

            //PAUSE
            Console.ReadLine();


        }//end main



    }//end class

    class Car
    {
        public string Make { get; set; }
        public string Model { get; set; }
        public string VIN { get; set; }

    }//end Car class

    class Employee
    {
        public string Name { get; set; }
        public string Title { get; set; }
        public string Dept { get; set; }
    }


}//end namespace
