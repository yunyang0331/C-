﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary
{
    public class AccessWeb
    {
        //one method
        public string GetWebPage( string url)
        {
            WebClient client = new WebClient();
            return client.DownloadString(url);
        }




    }//end class

}//end namespace
