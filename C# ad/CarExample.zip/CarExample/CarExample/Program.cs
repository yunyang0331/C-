﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarExample
{
    class Program
    {
        static void Main(string[] args)
        {
            //create first instance of car
            Car car = new Car("RED");
            Console.WriteLine(car.Describe());

            Car car2 = new Car("Green");
            Console.WriteLine(car2.Describe());

            car2.Color = "Blue";
            Console.WriteLine(car2.Describe());
           
            //pause
            Console.ReadLine();

        }//end main

    }//end class
     class Car
    { //efine instance vars
        private string color;

        //create constructor
        public Car(string color)
        {
            this.color = color;
        }
        //property for color-set and get
        public string Color
        {
            get { return color; }
            set { color = value; }
        }

        //one more method to display info
        public string Describe()
        {
            return "this car is " + color;
        }
    }//end class


}//end namespace
