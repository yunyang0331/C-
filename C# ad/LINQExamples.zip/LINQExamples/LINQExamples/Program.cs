﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQExamples
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Car> myCars = new List<Car>()
            {
                new Car() { VIN="A1",Make="BMW",Model="328i",Price=40000,Year=2016},
                new Car() { VIN = "B2", Make = "Toyota", Model = "Camry", Price = 30000, Year = 2016 },
                new Car() { VIN = "C3", Make = "BMW", Model = "745li", Price = 750000, Year = 2015 },
                new Car() { VIN = "D4", Make = "Chevy", Model = "Camaro", Price = 35000, Year = 2017 },
                new Car() { VIN = "E5", Make = "BMW", Model = "330i", Price = 40000, Year = 2017 }
            };

            //LINQ Query
            var bmws = from car in myCars
                       where car.Make == "BMW"
                       || car.Year == 2017
                       select car;

            //show results
            foreach(var car in bmws)
            {
                Console.WriteLine("{0} {1}", car.Make, car.Model);
            }

            Console.WriteLine("-------------------------");
            //LINQ Method (ANOTHER WAY TO DO IT)
            var bmws1 = myCars.Where(p => p.Make == "BMW" && p.Year == 2017);


            //show results
            foreach (var car in bmws1)
            {
                Console.WriteLine("{0} {1}", car.Make, car.Model);
            }

            ////////////////////////////////////////////////////////
            //Another example of using order
            var orderedCars = from car in myCars
                              orderby car.Year descending
                              select car;
            Console.WriteLine("-------------------------");
            //show results
            foreach (var car in orderedCars)
            {
                Console.WriteLine("{0} {1} {2}", car.Year, car.Make, car.Model);
            }

            //order by LINQ METHOD (ANOTHER WAY TO DO IT)
            var orderedCars1 = myCars.OrderByDescending(p => p.Year);
            Console.WriteLine("-------------------------");
            //show results
            foreach (var car in orderedCars1)
            {
                Console.WriteLine("{0} {1} {2}", car.Year, car.Make, car.Model);
            }

            //////////////////////////////////////////////////////////
            //example of using first and getting descending by year
            var firstBMW = myCars.OrderByDescending(P =>P.Year).First(P => P.Make == "BMW");
            Console.WriteLine("-------------------------");
            //show results
            Console.WriteLine("{0} {1} {2}", firstBMW.Year, firstBMW.Make, firstBMW.Model);

            //statement to see all cars newer than 2012
            if(myCars.TrueForAll(p=>p.Year > 2012))
            {
                Console.WriteLine("All cars are newer than 2012");
            }


            //sum up prices
            double sum = myCars.Sum(p => p.Price);
            Console.WriteLine("{0:C}", sum);

            //LINQ Query
            var bmwsNew = from car in myCars
                       where car.Make == "BMW"
                       select new { car.Make, car.Model };

            //show results
            foreach (var car in bmwsNew)
            {
                Console.WriteLine("{0} {1}", car.Make, car.Model);
            }


            //PAUSE
            Console.ReadLine();

        }//end main
    }//end class

    //create car class
    class Car
    {
        public string VIN { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public double Price { get; set; }
        public int Year { get; set; }




    }//end car class



}//emd namespace
