﻿using MyLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyClient
{
    class Program
    {
        static void Main(string[] args)
        {
            //test our method in MyLibrary
            AccessWeb myAccessWeb = new AccessWeb();

            //let us see what it does
            string text = myAccessWeb.GetWebPage("http://espn.com");
            Console.WriteLine(text);

            //pause
            Console.ReadLine();


        }//end main
    }//end class
}//end namespace
