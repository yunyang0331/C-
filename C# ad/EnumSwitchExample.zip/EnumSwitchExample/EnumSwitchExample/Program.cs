﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnumSwitchExample
{
    class Program
    {
        static void Main(string[] args)
        {
            //Using Enums-limit the possible values of a given variable
            List<Todo> todos = new List<Todo>()
            {
                new Todo {Desription="Grocery shop", EstimatedHours=2, Status=Status.NotStarted, Days=Days.Monday },
                new Todo {Desription="Study Advanced C", EstimatedHours=8, Status=Status.Completed, Days=Days.Tuesday},
                new Todo {Desription="Laundry",EstimatedHours=3, Status=Status.InProg, Days=Days.Wednesay },
                new Todo {Desription="Pick up kid",EstimatedHours=1, Status=Status.OnHold, Days=Days.Friday }

            };

            PrintTasks(todos);

        }//end main

        private static void PrintTasks(List<Todo> todos)
        {
            foreach(var task in todos)
            {
                switch (task.Status)
                {
                    case Status.Completed:
                        Console.ForegroundColor = ConsoleColor.Green;
                        break;

                    case Status.InProg:
                        Console.ForegroundColor = ConsoleColor.Red;
                        break;

                    case Status.NotStarted:
                        Console.ForegroundColor = ConsoleColor.DarkGreen;
                        break;

                    case Status.OnHold:
                        Console.ForegroundColor = ConsoleColor.Blue;
                        break;

                    default:
                        break;

                }//end switch
                Console.WriteLine(task.Desription);
         

            }//end foreach
            foreach (var tasks1 in todos)
            {
                switch (tasks1.Days)
                {
                    case Days.Monday:
                        Console.WriteLine(tasks1.Desription + " will be done on  " + Days.Monday);
                        break;

                    case Days.Tuesday:
                        Console.WriteLine(tasks1.Desription + " will be done on  " + Days.Tuesday);
                        break;

                    case Days.Friday:
                        Console.WriteLine(tasks1.Desription + " will be done on  " + Days.Friday);
                        break;

                    default:
                        break;

                }
                   

               
            }

             //pause
            Console.ReadLine();


        }//end PrintTasks method


    }//end class

    class Todo
    {
        public string Desription { get; set; }
        public int EstimatedHours { get; set; }
        public Status Status { get; set; }

        public Days Days { get; set; }



    }//end Todu class
    enum Status
    {
        NotStarted,
        InProg,
        OnHold,
        Completed

    }//end enum status

    enum Days
    {
        Monday,
        Tuesday,
        Wednesay,
        Tursday,
        Friday,
        Saturday,
        Sunday
      

    }//end Day 

}//end namespace
